package ir.erp.organization;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication(scanBasePackages="ir.erp")
public class OrganizationApplication {public static void main(String[] args) {SpringApplication.run(OrganizationApplication.class,args);}}
